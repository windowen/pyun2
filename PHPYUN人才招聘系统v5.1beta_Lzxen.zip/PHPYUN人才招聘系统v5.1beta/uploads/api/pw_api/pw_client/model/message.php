<?php
class messagemodel {
    //TODO 暂未实现
}
