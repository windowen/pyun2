<?php
class friendmodel {
    //TODO 暂未实现
}
?>