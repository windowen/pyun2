<?php
class friendcontrol {
    
}
?>