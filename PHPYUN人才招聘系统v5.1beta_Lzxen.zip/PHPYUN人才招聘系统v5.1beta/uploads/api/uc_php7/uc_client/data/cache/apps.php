<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZX',
    'name' => 'Discuz! Board',
    'url' => 'http://x.ghzpb.com',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  3 => 
  array (
    'appid' => '3',
    'type' => 'OTHER',
    'name' => '广海招聘宝',
    'url' => 'http://www.ghzpb.com',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc/uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://x.ghzpb.com/uc_server',
);
