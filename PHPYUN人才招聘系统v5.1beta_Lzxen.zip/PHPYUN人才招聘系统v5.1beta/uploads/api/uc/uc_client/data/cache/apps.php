<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZX',
    'name' => 'Discuz! Board',
    'url' => 'http://localhost/discuz',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => '',
    'recvnote' => '1',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'phpyun',
    'url' => 'http://www.job.com',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc/uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => 
      array (
        0 => 'http://www.job.com',
      ),
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://localhost/discuz/uc_server',
);
